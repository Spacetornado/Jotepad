﻿# Jotepad

A Valheim mod that adds a To-Do task/checklist.


## Features

GUI checklist that opens when you press Insert (keybind not configurable yet).
Add custom items to the list.
Click Clear to delete the entire list (wishlist item: remove individual items, and/or strikethrough the font).
Click Close to hide the list (or press Insert again).


## Changelog

No changes yet.


## Known issues and source code

You can find the github at:

https://github.com/Spacetornado/Jotepad

﻿# Jotepad

A Valheim mod that adds a To-Do task/checklist.


## Features

GUI that you toggle on/off.
Dropdown list of common tasks to quickly add to your To Do list.


## Changelog

No changes yet.


## Known issues and source code

You can find the github at:

https://github.com/Spacetornado/Jotepad
